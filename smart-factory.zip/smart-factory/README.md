# 스마트 팩토리 (Smart Factory System)

프레스 부품 제조 MES 데모

## 실행
```bash
npm install
npm run dev
```

## 빌드 & 배포
```bash
npm run build
```
Netlify/Vercel: Build command `npm run build`, Publish directory `dist`
